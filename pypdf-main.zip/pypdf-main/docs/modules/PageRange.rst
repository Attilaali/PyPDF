The PageRange Class
-------------------

.. autoclass:: pypdf.PageRange
    :members:
    :undoc-members:
    :show-inheritance:
