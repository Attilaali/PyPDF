The Transformation Class
------------------------

.. autoclass:: pypdf.Transformation
    :members:
    :undoc-members:
    :show-inheritance:
