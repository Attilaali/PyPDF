The Destination Class
---------------------

.. autoclass:: pypdf.generic.Destination
    :members:
    :undoc-members:
    :show-inheritance:
