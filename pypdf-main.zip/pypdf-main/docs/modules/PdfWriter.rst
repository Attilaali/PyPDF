The PdfWriter Class
-------------------

.. autoclass:: pypdf.PdfWriter
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: pypdf.ObjectDeletionFlag
    :members:
    :undoc-members:
    :show-inheritance:
