The Fit Class
-------------

.. autoclass:: pypdf.generic.Fit
    :members:
    :undoc-members:
    :show-inheritance:
