The PdfDocCommon Class
----------------------

**PdfDocCommon** is an abstract class which is inherited by :class:`~pypdf.PdfReader` and :class:`~pypdf.PdfWriter`.

Where identified in the API, you can use any of the derived class.

.. autoclass:: pypdf._doc_common.PdfDocCommon
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
