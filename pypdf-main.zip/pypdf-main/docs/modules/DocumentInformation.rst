The DocumentInformation Class
-----------------------------

.. autoclass:: pypdf.DocumentInformation
    :members:
    :undoc-members:
    :show-inheritance:
