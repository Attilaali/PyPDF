The PdfReader Class
-------------------

.. autoclass:: pypdf.PdfReader
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: pypdf.PasswordType
    :members:
    :undoc-members:
    :show-inheritance:
