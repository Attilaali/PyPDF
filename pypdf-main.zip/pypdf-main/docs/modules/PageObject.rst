The PageObject Class
--------------------

.. autoclass:: pypdf._page.PageObject
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: pypdf._page.VirtualListImages
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: pypdf._page.ImageFile
    :members:
    :inherited-members: File
    :undoc-members:

.. autofunction:: pypdf.mult
